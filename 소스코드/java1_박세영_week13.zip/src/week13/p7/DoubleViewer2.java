package week13.p7;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class DoubleViewer2 {

	private JFrame frame;
	private JPanel panel;
	final JButton button1;
	final JButton button2;
	final JLabel label1;
	final JLabel label2;
	
	public DoubleViewer2()
	{
		frame = new JFrame();
		panel = new JPanel();
		button1 = new JButton("A");
		button2 = new JButton("B");
		label1 = new JLabel("버튼 클릭수 : 0");
		label2 = new JLabel("버튼 클릭수 : 0");
		
		panel.add(button1);
		panel.add(label1);
		panel.add(button2);
		panel.add(label2);
		frame.add(panel);
		
		class ClickListener implements ActionListener {

			// 이벤트가 발생하여 이 메소드가 호출될 때 ActionEvent 객체가 파라미터로 전달.
			// ActionEvent 객체는 구체적으로 어떤 이벤트가 일어났는지 상세한 정보를 가지고 있다.
			// ActionEvent에게 getSource() 메소드를 호출하면 이벤트 소스를 알려준다.
			
			public void actionPerformed(ActionEvent event) {
				if(event.getSource() == button1)
				{
					n++;
					label1.setText("버튼 클릭수 : "+n);
				}
				else if(event.getSource() == button2)
				{
					n++;
					label2.setText("버튼 클릭수 : "+n);
				}
				
				
			}
			private int n;
		}
		
		ActionListener listener = new ClickListener();
		
		button1.addActionListener(listener);
		button2.addActionListener(listener);
		
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
	}
	
	public static void main(String[] args)
	{
		new DoubleViewer2();
	}
}
