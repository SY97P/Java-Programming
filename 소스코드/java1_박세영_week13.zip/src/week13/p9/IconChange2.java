package week13.p9;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * IconChange�� ���� ����� ������ ��ư�� �ι� ������ �۵��ϴ� Ŭ����
 * 
 * @author samsung
 *
 */
public class IconChange2 extends JPanel {

	public IconChange2() { // ������

		// Icon ����
		final ImageIcon angryBird = createImageIcon(
				"/images/angry-bird-icon.png", "Angry bird");
		final ImageIcon bee = createImageIcon("/images/bee-icon.png", "Bee");
		final ImageIcon bird = createImageIcon("/images/bird-icon.png", "Bird");
		final ImageIcon cat = createImageIcon("/images/cat-icon.png", "Cat");
		final ImageIcon clownFish = createImageIcon(
				"/images/clown-fish-icon.png", "Clown fish");
		final ImageIcon cow = createImageIcon("/images/cow-icon.png", "Cow");
		final ImageIcon dog = createImageIcon("/images/dog-icon.png", "Dog");
		final ImageIcon eagles = createImageIcon("/images/eagles-icon.png",
				"Eagles");
		final ImageIcon elephant = createImageIcon("/images/elephant-icon.png",
				"Elephant");
		final ImageIcon fish = createImageIcon("/images/fish-icon.png", "Fish");
		final ImageIcon jellyFish = createImageIcon(
				"/images/jelly-fish-icon.png", "Jelly fish");
		final ImageIcon lion = createImageIcon("/images/lion-icon.png", "Lion");
		final ImageIcon owl = createImageIcon("/images/owl-icon.png", "Owl");
		final ImageIcon redFish = createImageIcon("/images/red-fish-icon.png",
				"Red fish");
		final ImageIcon snack = createImageIcon("/images/snake-icon.png",
				"Snack");
		final ImageIcon tiger = createImageIcon("/images/tiger-icon.png",
				"Tiger");

		// ArrayList ����
		ArrayList<ImageIcon> list = new ArrayList<ImageIcon>();
		list.add(angryBird);
		list.add(bee);
		list.add(bird);
		list.add(cat);
		list.add(clownFish);
		list.add(cow);
		list.add(dog);
		list.add(eagles);
		list.add(elephant);
		list.add(fish);
		list.add(jellyFish);
		list.add(lion);
		list.add(owl);
		list.add(redFish);
		list.add(snack);
		list.add(tiger);

		// ��ư�� �ϳ��� �������.
		final JButton button = new JButton(list.get(0));

		class ClickListener implements ActionListener {
			boolean click = false;
			int i=0;
			public void actionPerformed(ActionEvent e) {
				if(click == false)
					click = true;
				else
				{
					if(i==15)
						i=0;
					else
						i++;
					button.setIcon(list.get(i));
					click = false;
					
				}
			}
		}
		
		//������ ��ü�� ����� ��ư�� ���
		ActionListener listener = new ClickListener();
		
		button.addActionListener(listener);
		
		add(button);
	}

	/**
	 * �̹��� ������ �о� ImageIcon ���·� ��ȯ�ϴ� �޼ҵ�. Returns an ImageIcon, or null if the
	 * path was invalid.
	 */
	protected static ImageIcon createImageIcon(String path, String description) {
		java.net.URL imgURL = ButtonPanel.class.getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}

	public static void main(String[] args) {
		// Create and set up the window.
		JFrame frame = new JFrame("Buttons for Image Switch");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Add content to the window.
		frame.add(new IconChange2());

		// Display the window.
		frame.pack();
		frame.setVisible(true);
	}
}
