package week13.p10;


//TicTacToe.java ------------------------------------------------


/**
A 3 x 3 tic-tac-toe board.
3행, 3열의 판을 만들어 놓는다.
*/
public class TicTacToe
{
	private String[][] board;
	private static final int ROWS = 3;
	private static final int COLUMNS = 3;

	/**
Constructs an empty board.
빈 판을 만들어 주는 구성자.
	 */
	public TicTacToe()
	{
		board = new String[ROWS][COLUMNS];
		// Fill with spaces
		for (int i = 0; i < ROWS; i++)
			for (int j = 0; j < COLUMNS; j++)
				board[i][j] = " ";
	}

	/**
Sets a field in the board. The field must be unoccupied.
판의 필드를 바꾼다. 이 필드는 점령되지 않았다.
@param i the row index 열 인덱스
@param j the column index 행 인덱스
@param player the player ("x" or "o")
	 */
	public void set(int i, int j, String player)
	{
		if (board[i][j].equals(" "))
			board[i][j] = player;
	}

	/**
Creates a string representation of the board, such as
|x o|
| x |
| o |
@return the string representation
	 */
	public String toString()
	{
		String r = "";
		for (int i = 0; i < ROWS; i++)
		{
			r = r + "|";
			for (int j = 0; j < COLUMNS; j++) 
				r = r + board[i][j];
			r = r + "|\n";
		}
		return r;
	}
	public boolean isValid(int x, int y)
	{
		if( x >= ROWS || x < -1 || y >= COLUMNS || y < 0)	
			//파라미터의 값들이 판의 크기를 벗어나면 false를 반환.
			return false;
		else if(board[x][y].equals("X") || board[x][y].equals("O"))
			//파라미터들이 가리키는 판의 위치에 값이 이미 설정되었다면
			//(전에 먼저 눌렀다면) false를 반환.
			return false;
		else 
			//제대로 된 값이면 true를 반환.
			return true;
	}

	public String getWinner()
	{
		if(win("X"))
			//player x가 true 라면,
			return "X";
		else if(win("O"))
			//player o가 true 라면, 
			return "O";
		else 
			//player x,o 모두 true가 아니라면,
			//win 메소드의 값이 false 라면
			//=(가로, 세로, 대각선 중에 하나라도 다른 player가 있다면,)
			return "";
	}
	private boolean win(String player)
	{
		if(checkVertical(player) || checkHorizontal(player) || checkDiagonal(player))
			// 가로, 세로, 대각선이 모두 동일한 player(x or o)이면 true 반환.
			return true;
		else 
			// 가로, 세로, 대각선 중에 하나라도 다른 player가 있다면 false 반환.
			return false;
	}
	//가로 탐색(1열, 2열, 3열의 행 탐색)
	private boolean checkVertical(String player)
	{
		return ((board[0][0].equals(player) && board[0][1].equals(player) && board[0][2].equals(player))||
				(board[1][0].equals(player) && board[1][1].equals(player) && board[1][2].equals(player))||
				(board[2][0].equals(player) && board[2][1].equals(player) && board[2][2].equals(player)));
	}
	//세로 탐색(1행, 2행, 3행의 열 탐색)
	private boolean checkHorizontal(String player)
	{
		return ((board[0][0].equals(player) && board[1][0].equals(player) && board[2][0].equals(player))||
				(board[0][1].equals(player) && board[1][1].equals(player) && board[2][1].equals(player))||
				(board[0][2].equals(player) && board[1][2].equals(player) && board[2][2].equals(player)));
	}
	//대각선 탐색(왼쪽 편향, 오른쪽 편향 두개 밖에 없음)
	private boolean checkDiagonal(String player)
	{
		return ((board[0][0].equals(player) && board[1][1].equals(player) && board[2][2].equals(player))||
				(board[0][2].equals(player) && board[1][1].equals(player) && board[2][0].equals(player)));
	}
}
