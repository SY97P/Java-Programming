package week13.p8;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class BankAccountFrame extends JFrame {

	private JPanel panel;
	private JButton button;
	final JLabel label;
	final int INTEREST_R = 10;
	
	public BankAccountFrame()
	{
		// �ʵ带 ��� �ʱ�ȭ ���ְ� BankAccount ��ü�� ����.
		BankAccount bank = new BankAccount(1000.0);
		panel = new JPanel();
		button = new JButton("Add Interest");
		label = new JLabel("balance : "+bank.getBalance());
		
		panel.add(button);
		panel.add(label);
		add(panel);
		
		// ���ϰ� innerClass�� ����
		class BankAccountListener implements ActionListener
		{
			public void actionPerformed(ActionEvent event)
			{
				double interest = bank.getBalance();
				interest = interest * INTEREST_R * 0.01;
				bank.deposit(interest);
				label.setText("balance : "+bank.getBalance());
			}
		}
		
		ActionListener listener = new BankAccountListener();
		
		button.addActionListener(listener);
		
		pack();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	public static void main(String[] args)
	{
		new BankAccountFrame();
	}
}
