package week13.p8;

/**
 * ������ BankAccount Ŭ����
 *
 */
public class BankAccount {

	private double balance;
	
	public BankAccount()
	{
		this(0.0);
	}
	
	public BankAccount(double initialBalance)
	{
		this.balance = initialBalance;
	}
	
	public void deposit(double value)
	{
		balance = balance + value;
	}

	public double getBalance()
	{
		return balance;
	}
}
