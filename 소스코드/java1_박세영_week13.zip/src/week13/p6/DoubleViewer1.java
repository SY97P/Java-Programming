package week13.p6;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class DoubleViewer1 {

	private JFrame frame;
	private JPanel panel;
	final JButton button1;
	final JButton button2;
	final JLabel label1;
	final JLabel label2;

	public DoubleViewer1() {
		frame = new JFrame();
		panel = new JPanel();
		button1 = new JButton("A");
		button2 = new JButton("B");
		label1 = new JLabel("A버튼 클릭수 : 0");
		label2 = new JLabel("B버튼 클릭수 : 0");

		panel.add(button1);
		panel.add(label1);
		panel.add(button2);
		panel.add(label2);
		frame.add(panel);

		class ClickListener implements ActionListener {

			public void actionPerformed(ActionEvent event) {
				if (event.getSource() == button1) {
					n++;
					label1.setText("A버튼 클릭수 : " + n);
				} else if (event.getSource() == button2) {
					n++;
					label2.setText("B버튼 클릭수 : " + n);
				}
			}

			private int n;
		}

		ActionListener listener1 = new ClickListener();
		ActionListener listener2 = new ClickListener();

		button1.addActionListener(listener1);
		button2.addActionListener(listener2);

		frame.pack();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		new DoubleViewer1();
	}
}
