package week13.p3;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class viewer {

	public static void main(String[] args)
	{
		JFrame frame = new JFrame();
		JPanel panel = new JPanel();
		JButton button = new JButton("Click me!");
		final JTextField textField = new JTextField(20);
		
		panel.add(button);
		panel.add(textField);
		frame.add(panel);
		
		ActionListener listener = new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						n++;
						textField.setText("��ư Ŭ���� : "+n);
					}
					int n = 0;
				};
				
		button.addActionListener(listener);
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
	}
}
