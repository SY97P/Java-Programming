package week13.p4;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class ButtonFrame extends JFrame {

	private JLabel label;	// �ν��Ͻ� �ʵ� 
	private JPanel panel;
	private JButton button;
	
	//������
	public ButtonFrame()
	{
		label = new JLabel("��ư Ŭ���� : 0");
		panel = new JPanel();
		button = new JButton("Click me!");
		
		panel.add(button);
		panel.add(label);
		
		add(panel);
		
		ActionListener listener = new ActionListener()
		{
			private int n;
			public void actionPerformed(ActionEvent event) {
				n++;
				label.setText("��ư Ŭ���� : "+n);
			}
			
		};
		button.addActionListener(listener);
		
		setSize(200, 150);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
	}
	
	public static void main(String[] args)
	{
		new ButtonFrame();
	}
}
