package week13.p5;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;

public class ClickListener implements ActionListener {

	ClickListener(JLabel jl)
	{
		label = jl;
	}
	public void actionPerformed(ActionEvent event) 
	{
		n++;
		label.setText("��ư Ŭ���� : "+n);
	}
	
	private int n;
	JLabel label;
}
