package week13.p5;

import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class DoubleViewer {

	private JFrame frame;
	private JPanel panel;
	private JButton button1;
	private JButton button2;
	final JLabel label1;
	final JLabel label2;
	
	public DoubleViewer()
	{
		frame = new JFrame();
		panel = new JPanel();
		button1 = new JButton("A");
		button2 = new JButton("B");
		label1 = new JLabel("��ư Ŭ���� : 0");
		label2 = new JLabel("��ư Ŭ���� : 0");
		
		panel.add(button1);
		panel.add(label1);
		panel.add(button2);
		panel.add(label2);
		
		frame.add(panel);
		
		ActionListener listener1 = new ClickListener(label1);
		ActionListener listener2 = new ClickListener(label2);
		
		button1.addActionListener(listener1);
		button2.addActionListener(listener2);
		
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
	}
	
	public static void main(String[] args)
	{
		new DoubleViewer();
	}
}
