package week11.linkedlist;


public class ListClient {
    public static void main(String[] args) {
        // add elements to end of list
        LinkedIntList list = new LinkedIntList();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        
        // add elements at an index
        list.add(2, 999);
        list.add(0, 12345);
        list.add(1, 777);
        list.add(3, 8765);
        
        for (int i = 0; i < 8; i++) {
            System.out.println(list.get(i));
        }
        //��� 12345 777 1 8765 2 999 3 4
        System.out.println();
        
        //remove
        list.remove(5);
        list.remove(3);
        list.remove(1);
        list.remove(0);
        
        for(int i = 0; i<4; i++)
        {
        	System.out.println(list.get(i));
        }
        // 1 2 3 4
        System.out.println();
        
        System.out.println(list.isEmpty());
        System.out.println();
        
        list.set(2, 7);
        for(int i = 0; i<4; i++)
        {
        	System.out.println(list.get(i));
        }
        System.out.println();
        
        System.out.println(list.size());
        System.out.println();
        
        list.remove(0);
        list.remove(0);
        list.remove(0);
        list.remove(0);
        System.out.println(list.toString());
        
        System.out.println(list.isEmpty());
    }
}
