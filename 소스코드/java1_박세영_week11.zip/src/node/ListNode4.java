package node;

public class ListNode4 {

	public static void main(String[] args)
	{
		ListNode list = new ListNode(990, null);
		
		for(int i=98; i>0; i--)
		{
			list = new ListNode(10*i, list);
		}
		
		ListNode current = list;
		while(current != null)
		{
			current = current.next;
			if(current.next == null)
			{
				current.next = new ListNode(1000);
			}
		}
		
		while(list != null)
		{
			System.out.println(list.data);
			list = list.next;
		}
	}
}
