package node;

public class ListNode1 {

	 public static void main(String[] args) {
	        ListNode list = new ListNode(10);
	        list.next = new ListNode(20);
	        list.next.next = new ListNode(30);
	        
	        System.out.println(list.data + " " + list.next.data
	                           + " " + list.next.next.data);
}
}
