package node;

public class ListNode2 {

	 public static void main(String[] args) {
	        ListNode list = new ListNode(20, null);
	        list = new ListNode(10, list);
	        list = new ListNode(30, list);
	        
	        
	        System.out.println(list.data + " " + list.next.data
	                           + " " + list.next.next.data);
	 }
}