package week9.arraylist2;

/**
 * In Eclipse package explorer, Run As -> Junit Test.
 */

import static org.junit.Assert.*;                                                    
import org.junit.Test;                               

public class ArrayIntListTest {  
	
	// Checks the basic functionality of the size method after adding a few elements.
	// ArrayIntList 클래스의 size 메소드를 테스트하는 테스트
	@Test                                         
	public void testSize() {                                     
		ArrayIntList list = new ArrayIntList();                                                      
		list.add(42);                                     
		list.add(-3);                               
		list.add(17);                                                         
		list.add(999);                                               
		assertEquals(4, list.size());                                                     
	}                               

	// Checks the basic functionality of the isEmpty method after adding and removing.
	// ArrayIntList 클래스의 isEmpty 메소드를 테스트하는 테스트
	@Test                                     
	public void testIsEmpty() {                               
		ArrayIntList list = new ArrayIntList();                                            
		assertTrue(list.isEmpty());                                               

		list.add(42);                                           
		assertFalse(list.isEmpty());                                         
		list.add(-3);                                              
		assertFalse(list.isEmpty());                                       

		list.remove(1);
		list.remove(0);
		assertTrue(list.isEmpty());                                                  
	}                                               

	// get ¸Þ¼Òµå·Î º¸³»Áö´Â ÀÎµ¦½º°¡ ÀüÁ¦Á¶°Ç¿¡ ¸Âµµ·Ï °­Á¦ÇÏ´Â ±â´ÉÀ» Å×½ºÆ®ÇÔ.
	// ÀÎµ¦½º °ªÀÌ ÀüÁ¦Á¶°ÇÀ» ¸¸Á·ÇÏÁö ¸øÇÏ¸é exceptionÀÌ ¹ß»ýµÇ¾î¾ß ÇÔ.
	// ¸¸¾à exceptionÀÌ ¹ß»ýÇÏÁö ¾Ê´Â´Ù¸é Å×½ºÆ® ½ÇÆÐ.
	// ArrayIntList 클래스의 get 메소드를 테스트하는 테스트
	@Test(expected = ArrayIndexOutOfBoundsException.class)                                 
	public void testGet() {                                            
		ArrayIntList list = new ArrayIntList();                                            
		list.get(17);   // this should crash                               
	}                                                    

	// Checks the basic functionality of the indexOf method after adding a few elements.
	// ArrayIntList 클래스의 indexof 메소드를 테스트하는 테스트
	@Test                                                   
	public void testIndexOf() {                                     
		ArrayIntList list = new ArrayIntList();                               
		list.add(42);                                      
		list.add(-3);                                         
		list.add(17);                                            
		list.add(999);                                     
		list.add(17);                                                   
		list.add(86);
		assertEquals(0, list.indexOf(42));
		assertEquals(5, list.indexOf(86));
		assertEquals(2, list.indexOf(17));         // not 4!
		assertEquals(-1, list.indexOf(5555555));   // not found in list
	}
	
	// 구성자의 capacity 인자 값이 음수일 때 IllegalArgumentException가 
	// 제대로 출력되는지 알아보는 테스트
	@Test(expected = IllegalArgumentException.class)
	public void testArrayIntList() {
		ArrayIntList list = new ArrayIntList(-5);
	}
	
	// 초기 용량을 초과하여 원소를 추가할 때 용량이 자동으로 늘어나는지를 테스트하는 테스트 메소드
	@Test 
	public void testCheckResize() {
		ArrayIntList list = new ArrayIntList();
		for(int i=0; i<10; i++)
		{
			list.add(i);
		}
		assertEquals(10, list.size());
		
		list.add(11);
		assertEquals(11, list.size());
		
		
	}
	
	//contains 메소드가 제대로 작동하는지 알아보는 메소드
	@Test
	public void testContains() {
		ArrayIntList list = new ArrayIntList();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		assertTrue(list.contains(4));
	}
	
	//리스트 중간에 원소를 삽입하는 add 기능을 테스트하는 메소드
	@Test
	public void testAdd() {
		ArrayIntList list = new ArrayIntList();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		list.add(6);
		list.add(3, 9);
	}
	
	// toString 메소드가 제대로 작동하는지 테스트하는 메소드
	// 특히 리스트에 원소가 하나 있을 때, 리스틑의 용량만큼 꽉 찼을 때
	// 리스트가 비어 있을 때 등의 경우에 제대로 작동하는지 테스트
	@Test
	public void testToString() {
		ArrayIntList list = new ArrayIntList();
		list.add(486);
		assertEquals("[486]", list.toString());
		
		for(int i=1; i<10; i++)
		{
			list.add(i);
		}
		assertEquals("[486, 1, 2, 3, 4, 5, 6, 7, 8, 9]", list.toString());
	}
}