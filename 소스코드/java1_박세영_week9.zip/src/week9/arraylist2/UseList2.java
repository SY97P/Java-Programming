package week9.arraylist2;

public class UseList2 {

	public static void main(String[] args) {
		
		ArrayIntList list = new ArrayIntList();
		
		list.add(12);
		list.add(-9);
		list.add(33);
		list.add(1024);
		
		list.add(0, 121);
		list.add(3, 444);

		list.remove(1);

		System.out.println(list);

		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		list.add(6);
		list.add(100);
		list.add(200);
		list.add(300);

		System.out.println(list);
		
		if (list.contains(300))
			System.out.println("300�� �ε���: " + list.indexOf(300));
		
		// �Ʒ� ����� �� ��� �ϳ��� �����ϸ� exception�� �߻��ؾ� �Ѵ�.
		
//		list.get(18);
//		list.add(18, 400);
//		ArrayIntList list2 = new ArrayIntList(-1);
		
	}

}