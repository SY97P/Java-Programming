package week14.p7;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JComponent;

public class RectangleComponent2 extends JComponent {

	private Rectangle2D.Double r;	//�ν��Ͻ� �ʵ�.
	
	public RectangleComponent2()
	{
		r = new Rectangle2D.Double(50.0, 50.0, 200.0, 200.0);
		
		setPreferredSize(new Dimension(300, 300));
	}
	
	public void larger()
	{
		double width = r.getWidth()+20.0;
		double height = r.getHeight()+20.0;
		r = new Rectangle2D.Double(50.0, 50.0, width, height);
		repaint();
	}
	
	public void smaller()
	{
		double width = r.getWidth()-20.0;
		if(width<0.0)
			width = 0.0;
		double height = r.getHeight()-20.0;
		if(height<0.0)
			height = 0.0;
		r = new Rectangle2D.Double(50.0, 50.0, width, height);
		repaint();
	}
	
	public void paintComponent(Graphics g)
	{
		Graphics2D g2 = (Graphics2D)g;
		g2.draw(r);
	}
}
