package week12;

// CSE 143, Winter 2011, Marty Stepp
// ListNode is a class for storing a single node of a linked list.
// A node stores a single value of data, along with a reference (link) to another
// node, which will be thought of as the next node in the overall chain.
// This class is going to be used to store part of a list of integer values.     

public class ListNode {
	public int data;
	public ListNode next;

	public ListNode(int data) {
		this.data = data;
		this.next = null;
	}

	public ListNode(int data, ListNode next) {
		this.data = data;
		this.next = next;
	}
}