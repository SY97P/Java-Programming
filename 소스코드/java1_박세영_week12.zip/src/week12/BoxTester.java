package week12;

import java.util.ArrayList;
import java.util.Random;

public class BoxTester {

	Random random = new Random();
	Box array[] = new Box[3];
	ArrayList<Box> list = new ArrayList<Box>();
	Box box = new Box();
	public void test()
	{
		//�ڽ� ��ü�� �迭�� arraylist�� �ִ´�.
		for(int i=0; i<3; i++)
		{
			double length = random.nextDouble()*100.0;
			double width = random.nextDouble()*100.0;
			double heigth = random.nextDouble()*100.0;
			
			box = new Box(length, width, heigth);
			//�迭�� �ִ´�.
			array[i] = box;
			//ArrayList�� �ִ´�.
			list.add(box);			
		}
		
		//for each�� �̿��� �迭 ���
		System.out.println("�迭 ���");
		for(Box boxx : array)
		{
			System.out.println(boxx.toString());
		}
		System.out.println();
		
		//for each�� �̿��� arraylist ���
		System.out.println("Array List ���");
		for(Box boxx : list)
		{
			System.out.println(boxx.toString());
		}
	}
	
	public static void main(String[] args)
	{
		BoxTester tester = new BoxTester();
		tester.test();
	}
}
