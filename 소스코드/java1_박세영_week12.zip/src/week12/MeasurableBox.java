package week12;

public class MeasurableBox implements Measurable{

	public MeasurableBox()
	{
		this(0.0, 0.0, 0.0);
	}
	
	public MeasurableBox(double length, double width, double height)
	{
		this.length = length;
		this.width = width;
		this.height = height;
	}
	
	public double getLength()
	{
		return length;
	}
	
	public double getWidth()
	{
		return width;
	}
	
	public double getHeight()
	{
		return height;
	}
	
	public String toString()
	{
		return String.format("Box[length=%.1f, width=%.1f, height=%.1f]", getLength(), getWidth(), getHeight());
	}

	public double getMeasure() 
	{
		return getLength()*getWidth()*getHeight();
	}
	
	private double length, width, height;

	
}
