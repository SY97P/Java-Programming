package week12;

public class BankAccount implements Measurable{

	double balance;
	
	public BankAccount()
	{
		this(0.0);
	}
	
	public BankAccount(double initialbalance)
	{
		this.balance = initialbalance;
	}
	
	public double getMeasure()
	{
		return balance;
	}
	
}
