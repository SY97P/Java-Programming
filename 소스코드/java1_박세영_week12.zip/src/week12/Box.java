package week12;

public class Box implements Comparable<Box>{

	public Box()
	{
		this(0.0, 0.0, 0.0);
	}
	
	public Box(double length, double width, double height)
	{
		this.length = length;
		this.width = width;
		this.height = height;
	}
	
	public double getLength()
	{
		return length;
	}
	
	public double getWidth()
	{
		return width;
	}
	
	public double getHeight()
	{
		return height;
	}
	
	public String toString()
	{
		return String.format("Box[length=%.1f, width=%.1f, height=%.1f]", getLength(), getWidth(), getHeight());
	}
	
	// Box�� 12���� �𼭸� �߿� ���� ū �𼭸��� ��ȯ
	public double bigLine()
	{
		double a = getLength();
		double b = getWidth();
		double c = getHeight();
		double E = 0.0;
		if(a<=b)
		{
			if(b<=c)
				c=E;
			else
				b=E;
		}
		else if(b<=c)
		{
			if(a<c)
				c=E;
			else
				a=E;
		}
		else if(c<b)
		{
			if(b<a)
				a=E;
			else
				b=E;
		}
		return E;
	}
	
	private double length, width, height;

	@Override
	public int compareTo(Box box) {
		if(bigLine()>box.bigLine())
			return -1;
		else if(bigLine()<box.bigLine())
			return 1;
		else
			return 0;
		
	}
}
