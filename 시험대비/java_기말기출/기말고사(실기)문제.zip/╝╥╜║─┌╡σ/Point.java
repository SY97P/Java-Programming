package java_final_problems;

public class Point {
    
	private double x = 0;
    private double y = 0;
    
    public Point(double x, double y){
        this.x = x;
        this.y = y;
    }
    
    public double getX()  {
        return this.x;
    }
    
    public double getY() {
        return this.y;
    }
    
    /**
     * �� �� ������ �Ÿ��� ���.
     * @param p1 ù ��
     * @param p2 �� ��° ��
     * @return p1, p2 ������ �Ÿ�
     */
    public static double distance(Point p1, Point p2) {
        return Math.sqrt(Math.pow((p1.getX() - p2.getX()), 2) + Math.pow((p1.getY() - p2.getY()), 2));
    }
    
    public String toString() {
    	return "Point[x=" + x + ",y=" + y + "]";
    }
    
    public static void main(String[] args) {
    	Point p1, p2;
    	p1 = new Point(3.0, 4.0);
    	p2 = new Point(1.0, 5.0);
    	double distance = Point.distance(p1,  p2);
    	System.out.println(p1);
    	System.out.println(p2);
    	System.out.format("�� �� ������ �Ÿ� = %.2f", distance);
    }
}